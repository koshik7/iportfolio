# iportfolio

3D Fortnite-style island portfolio (three.js). Static site: `index.html` plus Blender models in `assets/`.

```
index.html
vercel.json
assets/character.glb   (Blender: Shinigami avatar parts)
assets/world.glb       (Blender: cabin, vault, arena, tower)
```

If `assets/` is missing the page still works using built-in shapes.
Serve over http (for example `npx serve` or Vercel); opening the file directly skips the models.

Edit your details in the `D` block near the top of the script in `index.html`.
The in-page Admin editor only works on the Claude-hosted page, so it stays hidden here.
