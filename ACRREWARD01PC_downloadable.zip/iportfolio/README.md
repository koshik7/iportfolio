# iportfolio

3D Fortnite-style island portfolio (three.js). Static site: `index.html` plus Blender models in `assets/`.

```
index.html
vercel.json
assets/character.glb   (Blender: Shinigami avatar parts)
assets/world.glb       (Blender: cabin, vault, arena, tower)
```

If `assets/` is missing the page still works using built-in shapes.
Serve over http (for example `npx serve` or Vercel); opening the file directly skips the models.

Edit your details in the `D` block near the top of the script in `index.html`.
The in-page Admin editor only works on the Claude-hosted page, so it stays hidden here.

## Admin (Firebase)

1. Create a Firebase project, add a Web app, and paste its config (`apiKey`, `authDomain`, `projectId`, `appId`) into `FBC` in `index.html`.
2. Authentication > Sign-in method: enable **Email link (passwordless sign-in)**. Add your Vercel domain under Authentication > Settings > Authorized domains.
3. Build > Firestore Database: create a database, then paste `firestore.rules` into the Rules tab and publish. Only `koshikray777@gmail.com` can write.
4. Open the site, click **Admin**, press **Email me a sign-in link**, open the link from your inbox.

Certificate photos are shrunk in the browser and stored in Firestore (no paid plan needed).

## Credits

Character model: "Low Poly Ichigo based Guy" by edwardoooo, BlendSwap, CC-BY (https://blendswap.com/blend/15129). Add it here once it is used.
